/* Campus Connect: vanilla JS, no build step. Data is saved in this browser (localStorage). */
const KEY = "campus_v1";
let S = load();
let role = localStorage.getItem("campus_role") || "student";

function load() { try { const x = JSON.parse(localStorage.getItem(KEY)); if (x && x.buildings) return x; } catch (e) {} return JSON.parse(JSON.stringify(DEFAULTS)); }
function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
const today = () => new Date().toISOString().slice(0, 10);
const uid = p => p + Date.now().toString(36) + Math.floor(Math.random() * 99);
const canEdit = () => role !== "student";
const bName = id => (S.buildings.find(b => b.id === id) || {}).name || "Unknown";

/* tiny DOM helper (text only, so user input can never inject HTML) */
function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === "class") e.className = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) e.setAttribute(k, v);
  }
  kids.flat().forEach(c => e.append(c instanceof Node ? c : document.createTextNode(c == null ? "" : c)));
  return e;
}
const svg = (tag, attrs, ...kids) => {
  const e = document.createElementNS("http://www.w3.org/2000/svg", tag);
  for (const [k, v] of Object.entries(attrs || {})) e.setAttribute(k, v);
  kids.flat().forEach(c => e.append(c instanceof Node ? c : document.createTextNode(c)));
  return e;
};

/* attendance maths */
function pct(studentId, subjectId) {
  const ses = S.att.filter(a => a.subject === subjectId);
  if (!ses.length) return null;
  return Math.round(100 * ses.filter(a => a.marks[studentId] === true).length / ses.length);
}
const pctCell = p => h("td", { class: p === null ? "" : p < 75 ? "low" : "ok" }, p === null ? "-" : p + "%");

/* ---------- views ---------- */
function dashboard() {
  const all = S.subjects.flatMap(sb => S.students.map(st => pct(st.id, sb.id))).filter(x => x !== null);
  const avg = all.length ? Math.round(all.reduce((a, b) => a + b, 0) / all.length) : 0;
  const stat = (n, l) => h("div", { class: "card stat" }, h("b", {}, n), h("span", {}, l));
  return h("div", {},
    h("h1", {}, "Welcome to Campus Connect"),
    h("p", { class: "sub" }, "Find your teachers, track attendance and navigate the campus."),
    h("div", { class: "grid" },
      stat(S.teachers.filter(t => t.status === "Available").length + "/" + S.teachers.length, "Teachers available"),
      stat(S.students.length, "Students"),
      stat(S.att.filter(a => a.date === today()).length, "Sessions marked today"),
      stat(avg + "%", "Average attendance")),
    h("h2", {}, "Quick links"),
    h("div", { class: "bar" },
      h("a", { class: "btn", href: "#teachers" }, "Find a teacher"),
      h("a", { class: "btn", href: "#attendance" }, "Attendance"),
      h("a", { class: "btn", href: "#lab" }, "Lab attendance"),
      h("a", { class: "btn", href: "#map" }, "Campus map")));
}

function teachers() {
  const q = h("input", { type: "search", placeholder: "Search name or department", "aria-label": "Search" });
  const st = h("select", { "aria-label": "Status" }, h("option", { value: "" }, "All statuses"), STATUS.map(s => h("option", { value: s }, s)));
  const list = h("div", { class: "grid" });
  const draw = () => {
    const t = q.value.toLowerCase();
    const rows = S.teachers.filter(x => (x.name + x.dept).toLowerCase().includes(t) && (!st.value || x.status === st.value));
    list.replaceChildren(...rows.map(teacherCard));
    if (!rows.length) list.append(h("p", {}, "No teachers match."));
  };
  q.oninput = st.onchange = draw; draw();
  return h("div", {}, h("h1", {}, "Teacher tracker"),
    h("p", { class: "sub" }, "Teachers check in with their current location, so you can find them quickly."),
    h("div", { class: "bar" }, q, st), list);
}
function teacherCard(t) {
  const card = h("div", { class: "card t" },
    h("span", { class: "badge " + t.status.replace(/ /g, "") }, t.status),
    h("h3", {}, t.name), h("p", {}, t.dept + " department"),
    h("p", {}, "📍 " + bName(t.building) + ", " + t.room),
    h("p", {}, t.updated ? "Updated " + t.updated : "Not updated yet"),
    h("a", { class: "btn ghost", href: "#map/" + t.id }, "Show on map"));
  if (canEdit()) {
    const s = h("select", {}, STATUS.map(x => h("option", { value: x, selected: x === t.status ? "" : null }, x)));
    const b = h("select", {}, S.buildings.map(x => h("option", { value: x.id, selected: x.id === t.building ? "" : null }, x.name)));
    const r = h("input", { type: "text", value: t.room, "aria-label": "Room" });
    card.append(h("div", { class: "bar", style: "margin-top:12px" }, s, b, r,
      h("button", { onclick: () => { Object.assign(t, { status: s.value, building: b.value, room: r.value.trim() || "-", updated: new Date().toLocaleString() }); save(); route(); } }, "Update")));
  }
  return card;
}

function attendance(kind) {
  const subs = S.subjects.filter(s => s.kind === kind);
  const title = kind === "lab" ? "Lab attendance" : "Class attendance";
  const v = h("div", {}, h("h1", {}, title));
  if (!canEdit()) {
    v.append(h("p", { class: "sub" }, "Enter your roll number to see your attendance. Below 75% is highlighted."));
    const roll = h("input", { type: "text", placeholder: "e.g. 21CS001", "aria-label": "Roll number" });
    const out = h("div", { class: "wrap card" });
    const show = () => {
      const st = S.students.find(s => s.roll.toLowerCase() === roll.value.trim().toLowerCase());
      out.replaceChildren(st ? h("table", {}, h("tr", {}, h("th", {}, st.name), h("th", {}, "Attended"), h("th", {}, "%")),
        subs.map(sb => { const ses = S.att.filter(a => a.subject === sb.id), n = ses.filter(a => a.marks[st.id] === true).length;
          return h("tr", {}, h("td", {}, sb.name), h("td", {}, n + " / " + ses.length), pctCell(pct(st.id, sb.id))); }))
        : h("p", {}, roll.value ? "No student found with that roll number." : ""));
    };
    roll.oninput = show; v.append(h("div", { class: "bar" }, roll), out);
    return v;
  }
  v.append(h("p", { class: "sub" }, "Pick a date and subject, untick absentees and save."));
  const date = h("input", { type: "date", value: today(), "aria-label": "Date" });
  const sub = h("select", { "aria-label": "Subject" }, subs.map(s => h("option", { value: s.id }, s.name)));
  const msg = h("div", { class: "msg", role: "status" });
  const list = h("div", { class: "card" });
  let boxes = [];
  const draw = () => {
    const rec = S.att.find(a => a.date === date.value && a.subject === sub.value);
    boxes = S.students.map(st => {
      const cb = h("input", { type: "checkbox", id: "c" + st.id }); cb.checked = rec ? rec.marks[st.id] === true : true; cb._id = st.id; return cb;
    });
    list.replaceChildren(...S.students.map((st, i) => h("label", { class: "row", for: "c" + st.id }, boxes[i], st.roll + " · " + st.name)));
    msg.textContent = rec ? "Already saved for this session. Saving again will update it." : "";
  };
  date.onchange = sub.onchange = draw; draw();
  const setAll = val => boxes.forEach(b => b.checked = val);
  v.append(h("div", { class: "bar" }, date, sub,
    h("button", { class: "ghost", onclick: () => setAll(true) }, "All present"),
    h("button", { class: "ghost", onclick: () => setAll(false) }, "All absent")), list,
    h("div", { class: "bar", style: "margin-top:14px" }, h("button", { onclick: () => {
      if (!sub.value) return;
      const marks = {}; boxes.forEach(b => marks[b._id] = b.checked);
      const i = S.att.findIndex(a => a.date === date.value && a.subject === sub.value);
      const rec = { date: date.value, kind, subject: sub.value, marks };
      if (i >= 0) S.att[i] = rec; else S.att.push(rec);
      save(); msg.textContent = "Saved ✓ " + boxes.filter(b => b.checked).length + " present, " + boxes.filter(b => !b.checked).length + " absent."; report.replaceWith(report = makeReport());
    } }, "Save attendance")), msg, h("h2", {}, "Attendance summary"));
  const makeReport = () => h("div", { class: "card wrap" }, h("table", {},
    h("tr", {}, h("th", {}, "Student"), subs.map(s => h("th", {}, s.name))),
    S.students.map(st => h("tr", {}, h("td", {}, st.roll + " · " + st.name), subs.map(s => pctCell(pct(st.id, s.id)))))));
  let report = makeReport(); v.append(report);
  return v;
}

function campusMap(arg) {
  const sel = (S.teachers.find(t => t.id === arg) || {}).building || null;
  let chosen = sel;
  const info = h("div", { class: "card" });
  const show = id => {
    chosen = id; const b = S.buildings.find(x => x.id === id);
    document.querySelectorAll(".bld").forEach(n => n.classList.toggle("sel", n.dataset.id === id));
    const here = S.teachers.filter(t => t.building === id);
    info.replaceChildren(h("h3", {}, b.name), h("p", { class: "sub" }, b.info), h("h2", {}, "Teachers here"),
      ...(here.length ? here.map(t => h("p", {}, "• " + t.name + " (" + t.room + ", " + t.status + ")")) : [h("p", {}, "No teachers checked in here.")]));
  };
  const m = svg("svg", { id: "map", viewBox: "0 0 800 500", role: "img", "aria-label": "Campus map" });
  m.append(svg("rect", { x: 0, y: 160, width: 800, height: 30, fill: "#2a1a6e" }), svg("rect", { x: 0, y: 310, width: 800, height: 30, fill: "#2a1a6e" }),
    svg("text", { x: 400, y: 180, fill: "#9d8cff", "font-size": 11, "text-anchor": "middle" }, "MAIN ROAD"));
  S.buildings.forEach(b => {
    const g = svg("g", { class: "bld", "data-id": b.id, tabindex: 0, role: "button", "aria-label": b.name });
    g.append(svg("rect", { x: b.x, y: b.y, width: b.w, height: b.h, rx: 14, fill: b.fill, opacity: .85 }),
      svg("text", { x: b.x + b.w / 2, y: b.y + b.h / 2 + 4, fill: "#fff", "font-size": 13, "font-weight": 700, "text-anchor": "middle" }, b.name));
    g.onclick = () => show(b.id); g.onkeydown = e => { if (e.key === "Enter") show(b.id); };
    m.append(g);
  });
  S.buildings.forEach(b => S.teachers.filter(t => t.building === b.id).forEach((t, i) => {
    const hi = t.id === arg;
    const pin = svg("g", {}, svg("circle", { cx: b.x + 18 + i * 24, cy: b.y + b.h - 16, r: hi ? 12 : 10, fill: hi ? "#ff2bff" : "#fff", stroke: "#25105f", "stroke-width": 2 }),
      svg("text", { x: b.x + 18 + i * 24, y: b.y + b.h - 12, fill: "#25105f", "font-size": 9, "font-weight": 800, "text-anchor": "middle" }, t.name.replace(/^(Dr|Mr|Ms)\.? /, "").slice(0, 1)));
    pin.append(svg("title", {}, t.name + " – " + t.status)); pin.style.pointerEvents = "none"; m.append(pin);
  }));
  const find = h("select", { "aria-label": "Find building" }, h("option", { value: "" }, "Find a building…"), S.buildings.map(b => h("option", { value: b.id }, b.name)));
  find.onchange = () => find.value && show(find.value);
  const v = h("div", {}, h("h1", {}, "Campus map"), h("p", { class: "sub" }, "Tap a building. White dots are teachers, labelled by first letter."), h("div", { class: "bar" }, find),
    h("div", { class: "split" }, m, info));
  setTimeout(() => chosen ? show(chosen) : info.append(h("p", {}, "Select a building to see details.")));
  return v;
}

function admin() {
  if (role !== "admin") return h("div", {}, h("h1", {}, "Admin"), h("p", { class: "sub" }, "Switch the role to Admin (top right) to manage data."));
  const f = (label, el) => h("label", { class: "l" }, label, el);
  const done = h("div", { class: "msg", role: "status" });
  const tn = h("input", { type: "text" }), td = h("input", { type: "text" }), tr = h("input", { type: "text" });
  const tb = h("select", {}, S.buildings.map(b => h("option", { value: b.id }, b.name)));
  const sr = h("input", { type: "text" }), sn = h("input", { type: "text" });
  const bn = h("input", { type: "text" }), bk = h("select", {}, h("option", { value: "class" }, "Class"), h("option", { value: "lab" }, "Lab"));
  return h("div", {}, h("h1", {}, "Admin"), h("p", { class: "sub" }, "Add teachers, students and subjects. Export data as CSV."), done,
    h("div", { class: "grid" },
      h("form", { class: "f card", onsubmit: e => { e.preventDefault(); if (!tn.value.trim()) return; S.teachers.push({ id: uid("t"), name: tn.value.trim(), dept: td.value.trim() || "-", building: tb.value, room: tr.value.trim() || "-", status: "Away", updated: "" }); save(); done.textContent = "Teacher added ✓"; e.target.reset(); } },
        h("h3", {}, "Add teacher"), f("Name", tn), f("Department", td), f("Building", tb), f("Room", tr), h("button", {}, "Add teacher")),
      h("form", { class: "f card", onsubmit: e => { e.preventDefault(); if (!sr.value.trim() || !sn.value.trim()) return; S.students.push({ id: uid("s"), roll: sr.value.trim(), name: sn.value.trim() }); save(); done.textContent = "Student added ✓"; e.target.reset(); } },
        h("h3", {}, "Add student"), f("Roll number", sr), f("Name", sn), h("button", {}, "Add student")),
      h("form", { class: "f card", onsubmit: e => { e.preventDefault(); if (!bn.value.trim()) return; S.subjects.push({ id: uid("sub"), name: bn.value.trim(), kind: bk.value }); save(); done.textContent = "Subject added ✓"; e.target.reset(); } },
        h("h3", {}, "Add subject or lab"), f("Name", bn), f("Type", bk), h("button", {}, "Add subject"))),
    h("div", { class: "bar", style: "margin-top:20px" },
      h("button", { onclick: exportCsv }, "Export attendance CSV"),
      h("button", { class: "ghost", onclick: () => { if (confirm("Reset all data to the demo defaults?")) { S = JSON.parse(JSON.stringify(DEFAULTS)); save(); route(); } } }, "Reset demo data")));
}
function exportCsv() {
  const rows = [["date", "type", "subject", "roll", "name", "present"]];
  S.att.forEach(a => S.students.forEach(st => rows.push([a.date, a.kind, (S.subjects.find(s => s.id === a.subject) || {}).name, st.roll, st.name, a.marks[st.id] === true ? "yes" : "no"])));
  const csv = rows.map(r => r.map(c => '"' + String(c == null ? "" : c).replace(/"/g, '""') + '"').join(",")).join("\n");
  const a = h("a", { href: URL.createObjectURL(new Blob([csv], { type: "text/csv" })), download: "attendance.csv" }); a.click();
}

/* ---------- router ---------- */
const NAV = [["dashboard", "Home"], ["teachers", "Teachers"], ["attendance", "Attendance"], ["lab", "Lab"], ["map", "Map"], ["admin", "Admin"]];
function route() {
  const [r, arg] = (location.hash.slice(1) || "dashboard").split("/");
  const views = { dashboard, teachers, attendance: () => attendance("class"), lab: () => attendance("lab"), map: () => campusMap(arg), admin };
  const page = (views[r] || dashboard)(); 
  $nav(r); const v = document.getElementById("view"); v.replaceChildren(page);
}
function $nav(r) {
  document.getElementById("nav").replaceChildren(...NAV.filter(n => n[0] !== "admin" || role === "admin").map(n => h("a", { href: "#" + n[0], class: n[0] === r ? "on" : "" }, n[1])));
}
const roleSel = document.getElementById("role"); roleSel.value = role;
roleSel.onchange = () => { role = roleSel.value; localStorage.setItem("campus_role", role); route(); };
window.addEventListener("hashchange", route); route();
