/* Demo data. Edit this file to match your college, or use the Admin page. */
const STATUS = ["Available", "In class", "In lab", "On break", "Away"];
const DEFAULTS = {
  buildings: [
    { id: "gate", name: "Main Gate", x: 20, y: 200, w: 60, h: 100, fill: "#6b7280", info: "Entrance and security desk." },
    { id: "admin", name: "Admin Block", x: 110, y: 50, w: 170, h: 100, fill: "#7b4bff", info: "Principal office, accounts, admissions." },
    { id: "cse", name: "CSE & IT Block", x: 320, y: 50, w: 180, h: 100, fill: "#00a2ff", info: "Classrooms and faculty rooms for CSE and IT." },
    { id: "labs", name: "Computer Labs", x: 540, y: 50, w: 200, h: 100, fill: "#b400ff", info: "Lab 1 to Lab 4. Lab sessions run 9 AM to 4 PM." },
    { id: "library", name: "Library", x: 110, y: 200, w: 170, h: 100, fill: "#10b981", info: "Open 8 AM to 8 PM." },
    { id: "audi", name: "Auditorium", x: 320, y: 200, w: 180, h: 100, fill: "#ff2bff", info: "Events, seminars and guest lectures." },
    { id: "canteen", name: "Canteen", x: 540, y: 200, w: 110, h: 100, fill: "#f59e0b", info: "Open 8 AM to 6 PM." },
    { id: "hostel", name: "Hostel", x: 680, y: 200, w: 100, h: 100, fill: "#ef4444", info: "Boys and girls hostel." },
    { id: "sports", name: "Sports Ground", x: 110, y: 350, w: 300, h: 120, fill: "#22c55e", info: "Cricket, football and athletics track." },
    { id: "parking", name: "Parking", x: 450, y: 350, w: 200, h: 120, fill: "#64748b", info: "Staff and student parking." }
  ],
  teachers: [
    { id: "t1", name: "Dr. Priya Raman", dept: "CSE", building: "cse", room: "Room 204", status: "In class", updated: "" },
    { id: "t2", name: "Mr. Arun Kumar", dept: "IT", building: "labs", room: "Lab 2", status: "In lab", updated: "" },
    { id: "t3", name: "Ms. Divya Lakshmi", dept: "Maths", building: "cse", room: "Staff Room", status: "Available", updated: "" },
    { id: "t4", name: "Dr. Suresh Babu", dept: "Physics", building: "admin", room: "HOD Cabin", status: "Available", updated: "" },
    { id: "t5", name: "Mr. Karthik S", dept: "ECE", building: "library", room: "Reading Hall", status: "On break", updated: "" }
  ],
  students: [
    { id: "s1", roll: "21CS001", name: "Anitha R" }, { id: "s2", roll: "21CS002", name: "Bala M" },
    { id: "s3", roll: "21CS003", name: "Chitra S" }, { id: "s4", roll: "21CS004", name: "Dinesh K" },
    { id: "s5", roll: "21CS005", name: "Eswari P" }, { id: "s6", roll: "21CS006", name: "Farook A" }
  ],
  subjects: [
    { id: "sub1", name: "Data Structures", kind: "class" }, { id: "sub2", name: "Database Systems", kind: "class" },
    { id: "sub3", name: "Mathematics", kind: "class" },
    { id: "lab1", name: "Programming Lab", kind: "lab" }, { id: "lab2", name: "DBMS Lab", kind: "lab" }
  ],
  att: []
};
