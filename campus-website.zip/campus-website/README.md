# Campus Connect

A simple college campus website with:
- **Teacher tracker**: teachers check in their status and location; students search and see them on the map.
- **Class attendance** and **Lab attendance**: mark per date and subject, with per-student percentage (below 75% highlighted). Students look up their own record by roll number.
- **Campus map**: clickable SVG map with building details and teacher pins.
- **Admin page**: add teachers, students, subjects; export attendance as CSV.

## Run it
Unzip and double-click `index.html`. No installation needed.
To put it online, upload the folder to any static host (GitHub Pages, Netlify, your college server).

## Customise
- `js/data.js`: your buildings (map coordinates), teachers, students and subjects.
- `css/style.css`: colours and layout.

## Important limits of this version
- Data is saved in the browser (localStorage), so each device has its own copy. For a shared college-wide system, connect a backend (Firebase, Supabase or a Node/PHP server with a database).
- The Student/Teacher/Admin switch is a demo, not real login. Add proper authentication before real use.
- Teacher location is self-reported check-in, not GPS tracking. Tracking staff by GPS needs their consent and a college policy.
